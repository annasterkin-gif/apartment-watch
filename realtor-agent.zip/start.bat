@echo off
echo Starting Apartment Watch...
start "" http://localhost:3456
node apartment-config-ui.js
